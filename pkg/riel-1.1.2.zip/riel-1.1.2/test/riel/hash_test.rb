#!/usr/bin/ruby -w
# -*- ruby -*-

require 'rubyunit'
require 'riel/hash'

class HashTestCase < RUNIT::TestCase

  def test
  end

end
