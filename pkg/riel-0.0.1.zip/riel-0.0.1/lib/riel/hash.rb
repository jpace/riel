#!/usr/bin/ruby -w
# -*- ruby -*-

class Hash

  $-w = false
  def to_s
    "{ " + collect { |k, v| k.to_s + " => " + v.to_s }.join(", ") + " }"
  end
  $-w = true

end
